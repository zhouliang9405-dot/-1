# 苏轼年表网页部署包

这是一个纯静态网页，无需服务器程序。请将本目录内的所有文件放在同一个网站根目录：

- `index.html`：网页入口
- `sushi-works.js`、`sushi-life-works.js`：作品文本数据
- `northern-song-map.png`：北宋历史地图底图

## 发布到 GitHub Pages

1. 在 GitHub 新建一个公开仓库，例如 `sushi-timeline`。
2. 将本目录内的全部文件上传到仓库根目录并提交。
3. 打开仓库的 **Settings → Pages**。
4. 在 **Build and deployment** 中选择 **Deploy from a branch**，分支选 `main`，目录选 `/(root)`，保存。
5. 等待部署完成后，网页地址通常是 `https://你的用户名.github.io/sushi-timeline/`。

免费 GitHub 账号的 Pages 网站需要使用公开仓库；上传前请确认仓库内容可以公开。每个 JS 与图片文件必须和 `index.html` 保持同级，否则页面会缺作品或地图。
